package com.example.myapplication.model;

public class UserDAO {
}
